## Tavsiyeler

İzlemenizi tavsiye edebileceğim; görüntü işleme, bilgisayarlı görü ve derin öğrenme alanında yapılan seminerler, TED konuşmaları vb. organizasyonlar.

|    |            |   |
|----------|:-------------:|------:|
| Abe Davis |  Nesnelerin gizli özelliklerini ortaya çıkaran yeni video teknolojisi. Görüntü işlemede yeni bir yaklaşım. | [![](https://img.youtube.com/vi/npNYP2vzaPo/0.jpg)](https://www.youtube.com/watch?v=npNYP2vzaPo) |
| Fei-Fei Li | Resimleri anlamaları için bilgisayarları nasıl eğitiyoruz. Nesne tanıma ve anlamlandırma alanında uyguladıkları yaklaşımlar ve geldikleri durumu anlattığı bir konuşma. | [![](https://img.youtube.com/vi/40riCqvRoMs/0.jpg)](https://www.youtube.com/watch?v=40riCqvRoMs) |
| Chris Urmson |  Sürücüsüz bir araba yolu nasıl görür. Google Car projesin’de kullandıkları görüntü işleme metodolojileri ve yaşadıkları zorluklara buldukları çözümleri anlatmaktadır. | [![](https://img.youtube.com/vi/tiwVMrTLUWg/0.jpg)](https://www.youtube.com/watch?v=tiwVMrTLUWg) |
| Rana el Kaliouby |  Derin öğrenme çalışmaları. | [![](https://img.youtube.com/vi/o3VwYIazybI/0.jpg)](https://www.youtube.com/watch?v=o3VwYIazybI) |
| Marc Raibert|  Boston Dynamic robotları nasıl çalışıyor. | [![](https://img.youtube.com/vi/AO4In7d6X-c/0.jpg)](https://www.youtube.com/watch?v=AO4In7d6X-c) |
| Joseph Redmon |  Bilgisayarlar nesneleri nasıl tanır. | [![](https://img.youtube.com/vi/Cgxsv1riJhI/0.jpg)](https://www.youtube.com/watch?v=Cgxsv1riJhI) |
