# Kara Liste
İçeriklerin kaynak gösterilmeden kullanılması durumunda bu kişiler/kurumlar (kaynak belirtene kadar) burada listelenecektir. Bu projedeki kaynakların kötüye kullanımına dair birçok eposta almaktayım, bu gibi durumlarda iletişime geçmek yerine doğrudan bu bölüme ekleme yapabilirsiniz.

| Kişi/Kurum |Bağlantı|
|----------|--------|
|-|-|