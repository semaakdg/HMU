# Tesseract ile Optik Karakter Tanıma

İlgili klavuz: https://github.com/mesutpiskin/goruntu-isleme-kilavuzu/blob/master/docs/18-optik-karakter-tanima.md

## Bağımlılıklar
```Bash
pip install pytesseract
pip install opencv-python
```

### Çalıştırmak için


```Bash
python optik_karakter_tanima.py
```
