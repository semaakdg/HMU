**Terimler** 
------------
Burada, dokümantasyon içerisinde kullanılan İngilizce terimlerin Türkçe karşılığı yer almaktadır. Türkçe terimler seçilerken öncelikli olarak Türkiye Bilimler Akademisi Sözlüğü, kaynak kitaplar ve Deeplearning Türkiye Sözlüğü dikkate alınmıştır. Türkçe karşılığı herhangi bir yerde yer almayan terimleri ise kendim çevirmeye çalıştım. 

Bu  bölümdeki terimleri düzeltmekten veya yeni terim eklemekten çekinmeyin.

<hr/>

**Feature Based**: Öznitelik Tabanlı 

**Holistic Matching**: Bütünsel Eşleme 

