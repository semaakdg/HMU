import unittest
from main import *

class MaxValueTests(unittest.TestCase):
    def test_main(self): 
        self.assertIsInstance(highest, int)
        self.assertEqual(highest, 9)
