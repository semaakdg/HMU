def say_hello(greeting):
    return greeting

### Call the say_hello function below this line: ###

result = "Replace this string with the correct function call."

### Call the say_hello function above this line: ###
print(result)
