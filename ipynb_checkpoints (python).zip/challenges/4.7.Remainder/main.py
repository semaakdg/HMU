### Write your code below this line ###



### Write your code above this line ###

print(remainder)
