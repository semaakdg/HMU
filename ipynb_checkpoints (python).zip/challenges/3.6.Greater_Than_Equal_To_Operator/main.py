def greater_or_equal(value):
    if value :  # Change this line
        return "50 or more"
    elif value :  # Change this line
        return "20 or more"
    else:
        return "Less than 20"

# Change the value 1 below to experiment with different values
print(greater_or_equal(1))
