def boolean_or(value):
    if value:  # Complete the if clause on this line
        return "Try Again"
    else:
        return "Pass"

print(boolean_or(75))   # Change this value to test
