def identity_test(value):
    if value :  # Change this line
        return "Same object"
    else:
        return "Different object"

# Change the value 42 below to experiment with different values
print(identity_test(42))
