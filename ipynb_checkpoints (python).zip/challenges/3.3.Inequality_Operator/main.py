def inequality(value):
    # Complete the if statement on the next line using value, the inequality operator (!=), and the number 13.
    if value != 13:
    ### Your code goes above this line ###
        return "Not Equal to 13"
    else:
        return "Equal to 13"

print(inequality(100))
