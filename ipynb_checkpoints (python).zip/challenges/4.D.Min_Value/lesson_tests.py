import unittest
from main import *

class MinValueTests(unittest.TestCase):
    def test_main(self):
        self.assertIsInstance(lowest, int)
        self.assertEqual(lowest, 1)
