numbers = [8, 2, 4, 3, 6, 5, 9, 1]

### Modify the code below ###

lowest = numbers

### Modify the code above ###

print(lowest)
