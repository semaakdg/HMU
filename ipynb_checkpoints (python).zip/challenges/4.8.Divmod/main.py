a = 11
b = 3
### Write your code below this line ###



### Write your code above this line ###

print(result)
