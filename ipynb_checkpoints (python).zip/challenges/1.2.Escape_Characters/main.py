string_escape = 'Hello, this is escape string' # change this line

# change the string_escape, the string must contain "new line"
print(string_escape)