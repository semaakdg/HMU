import unittest
from main import *

class IntegerDivisionTests(unittest.TestCase):
    def test_main(self):
        self.assertIsInstance(quotient, int)
        self.assertEqual(quotient, 2)
