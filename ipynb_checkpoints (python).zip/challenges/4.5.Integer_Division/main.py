### Modify the code below ###

quotient = 5 // 5

### Modify the code above ###

print(quotient)
