import unittest
from main import *

class LoopsTests(unittest.TestCase):
    def test_main(self):
        self.assertTrue(switch_end)
        self.assertTrue(switch_loop)
