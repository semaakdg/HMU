count = 10  # Change this count
switch_loop = False
switch_end = False

while count < 9:
  	print('step ', count)
  	count = count + 1
  	switch_loop = True
# use else statements 
	print('loop end')
	switch_end = True;

