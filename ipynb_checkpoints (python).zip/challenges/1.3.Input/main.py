### Modify the code below ###

#Ask the user for their name!
Name = ''

#Ask the user for their age!
Age = ''

print(Name)
print(Age)

### Modify the code above ###
