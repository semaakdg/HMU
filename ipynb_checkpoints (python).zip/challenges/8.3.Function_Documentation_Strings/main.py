def docstring_function():
    ### Write your docstring below this line. ###



    ### Write your docstring above this line. ###
    pass

print(docstring_function.__doc__)
