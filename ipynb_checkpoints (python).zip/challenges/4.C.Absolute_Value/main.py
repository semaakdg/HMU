### Modify the code below ###

absolute_value = -42

### Modify the code above ###

print(absolute_value)
