def keyword_argument_example(your_age, **kwargs):
    return your_age, kwargs

### Write your code below this line ###

about_me = "Replace this string with the correct function call."

### Write your code above this line ###

print(about_me)
