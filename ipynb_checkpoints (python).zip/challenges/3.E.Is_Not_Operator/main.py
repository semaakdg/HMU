def negative_identity_test(value):
    if value :  # Change this line
        return "Different object"
    else:
        return "Same object"

# Change the value 84 below to experiment with different values
print(negative_identity_test(84))
