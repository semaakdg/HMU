### Modify the code below ###

total = 10 + 0

### Modify the code above ###

print(total)
