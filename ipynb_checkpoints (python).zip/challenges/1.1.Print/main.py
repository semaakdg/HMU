print('firstname', 'sname', sep='*', end='*') #change this line
