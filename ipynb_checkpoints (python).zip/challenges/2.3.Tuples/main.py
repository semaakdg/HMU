### Modify the code below ###

twoTuple = null

threeTuple = null

fiveTuple = null

tenTuple = null 

### Modify the code above ###
