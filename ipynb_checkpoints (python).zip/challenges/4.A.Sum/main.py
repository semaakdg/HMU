list1 = [1, 3, 5, 7, 9]
list2 = [2, 4, 6, 8, 10]

### Write your code below this line ###



### Write your code above this line ###

print(total)
