### Define the say_hello() function and fill in the function body below this line: ###



### Call the say_hello() function below this line: ###
say_hello()
