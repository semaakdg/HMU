### Modify the code below ###

mediumList = null

shortList = null

longList = null

### Modify the code above ###
