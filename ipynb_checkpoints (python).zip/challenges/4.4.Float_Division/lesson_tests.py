import unittest
from main import *

class FloatDivisionTests(unittest.TestCase):
    def test_main(self):
        self.assertIsInstance(quotient, float)
        self.assertEqual(quotient, 2.5)
