numbers = [6, 3, 1, 8, 5, 2, 4, 7]

### Assign the correct built-in function to the variable named result below: ###

result = "Replace this string with the correct answer"

### Write your code above this line
print(result)
