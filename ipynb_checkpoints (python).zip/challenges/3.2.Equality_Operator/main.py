def equality(value):
    # Complete the if statement on the next line using value, the equality operator (==), and the number 12.
    if :
    ### Your code goes above this line ###
        return "Equal to 12"
    else:
        return "Not Equal to 12"

print(equality(12))
