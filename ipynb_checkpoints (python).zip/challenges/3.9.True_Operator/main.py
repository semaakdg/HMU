def boolean_true():
    return value  # Change the varable named value to the correct answer

print(boolean_true())
