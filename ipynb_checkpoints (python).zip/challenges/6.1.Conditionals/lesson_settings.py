{
  "lesson_title": "Conditionals",
  "chapter_number": 6,
  "lesson_number": 1,
  "id":"5965e5fd60d67217f0ce232f",
  "repl": ""
}
