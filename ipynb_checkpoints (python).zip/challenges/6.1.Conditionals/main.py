value = 'some' #modify this line

if value == 'Y' or value == 'y':
    print('yes')
elif value == 'N' or value == 'n':
    print('no')
else:
    print('error')
