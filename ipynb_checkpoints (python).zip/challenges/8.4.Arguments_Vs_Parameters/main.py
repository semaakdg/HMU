### Define your function with the appropriate parameter below this line: ###



### Assign the function call with the appropriate argument to the variable named result below this line: ###

result = "Replace this string with the correct answer"

print(result)
