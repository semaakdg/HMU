def boolean_and(value):
    if value:  # Complete the if clause on this line
        return "Pass"
    else:
        return "Try Again"

print(boolean_and(40))  # Change this value to test
