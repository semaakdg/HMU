a = 3
b = 4

### Write your code below this line ###



### Write your code above this line ###

print(power)
