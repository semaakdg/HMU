### Modify the code below ###

myName = null

myAge = null

favoriteActivity = null

mySentence = null 

### Modify the code above ###
