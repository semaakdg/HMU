word = "wrong answer"
sentence = "The quick brown fox jumped over the lazy dog."

def membership_test():
    return word in sentence

print(membership_test())
