def boolean_not(value):
    pass  # replace the pass statement with the correct code

print(boolean_not(True))
