letter = 'a'
alphabet = 'abcdefghijklomnopqrstuvwxyz'

def non_membership_test():
    return letter not in alphabet

print(non_membership_test())
