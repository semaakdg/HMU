### Modify the code below ###

myInteger = null

myFloat = null

myComplex = null

### Modify the code above ###
