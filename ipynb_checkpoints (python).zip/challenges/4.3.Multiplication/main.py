### Modify the code below ###

product = 8 * 0

### Modify the code above ###

print(product)
